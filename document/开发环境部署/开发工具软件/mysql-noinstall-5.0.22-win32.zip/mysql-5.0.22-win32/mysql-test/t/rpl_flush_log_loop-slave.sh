rm -f $MYSQLTEST_VARDIR/master-data/master.info
rm -f $MYSQLTEST_VARDIR/master-data/*-bin.*
rm -f $MYSQLTEST_VARDIR/master-data/*.index

